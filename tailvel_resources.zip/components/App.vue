<template>
    <h1 class="text-center mb-8 font-bold">
        Vue 3 & Tailwind have been installed
    </h1>
</template>
<script>
</script>