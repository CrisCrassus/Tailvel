import {createApp} from "vue"

import App from "./components/App.vue"

const app = createApp({});

app.component("welcome-component", App);

app.mount("#app");